import sys

from robot.libraries.BuiltIn import BuiltIn
from webdriver_manager.chrome import ChromeDriverManager
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


def get_driver_path_with_browser():
    driver_path = ChromeDriverManager().install()
    print(driver_path)
    # chrome_options = Options()
    # chrome_options.add_argument("--incognito")
    # # driver = webdriver.Chrome(executable_path=webdriver.chrome(ChromeDriverManager().install()),chrome_options=chrome_options)
    # # driver.get('https://google.com')
    # # # return driver_path
    # # chrome_options.binary_location = "../Google Chrome"
    # chrome_options.add_argument("disable-infobars");
    # chrome_options.add_experimental_option("detach", True)
    #
    # driver = webdriver.Chrome(driver_path, options=chrome_options)
    # driver.maximize_window()
    # driver.get(url)
    return driver_path


# get_driver_path_with_browser("https://www.google.com/")

def open_browser_maximized():
    #exec_dir = BuiltIn().get_variable_value("${EXECDIR}")

    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--disable-gpu")
    # path = BuiltIn().get_variable_value("${path}")
    # logger.console("path is--"+str(path))
    if sys.platform.startswith('win32'):
        path = get_driver_path_with_browser()
    else:
        path = '/usr/local/bin/chromedriver'
        chrome_options.add_argument("--headless")

    #     if path==None:
    #         path = exec_dir + '/Files/Driver/Chrome/chromedriver.exe'
    #         #path = '/usr/local/bin/chromedriver'
    extra_args = {'executable_path': path}
    sl = BuiltIn().get_library_instance('SeleniumLibrary')
    sl.create_webdriver('Chrome', chrome_options=chrome_options, kwargs=extra_args)
    sl.maximize_browser_window()


def check_products(products):
    has_hsi = 'HSI' in products
    has_voice = 'VOICE' in products
    has_ipdata = 'IP_DATA' in products
    has_pots = 'POTS' in products

    if (has_hsi and has_voice) or (has_ipdata and has_pots):
        print("Both HSI and Voice or IP_DATA and POTS are present.")
    elif has_hsi or has_ipdata:
        print("Internet is present.")
    elif has_pots or has_voice:
        print("Phone is present.")

def verify_products(products):
    if ('HSI' in products and 'VOICE' in products) or ('IP_DATA' in products and 'POTS' in products):
        return 'Both internet and phone products are present'
    elif 'HSI' in products or 'IP_DATA' in products:
        return 'Only internet product is present'
    elif 'POTS' in products or 'VOICE' in products:
        return 'Only phone product is present'


# Example usage:
# check_products(['HSI', 'VOICE', 'IP_DATA', 'POTS'])  # prints "Both HSI and Voice or IP_DATA and POTS are present."
# check_products(['HSI', 'VOICE'])  # prints "Internet is present."
# check_products(['POTS'])  # prints "Phone is present."
