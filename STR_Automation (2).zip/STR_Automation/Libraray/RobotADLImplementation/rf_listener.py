import time
import datetime
import re
import json
import os
import base64
import requests
import xml.etree.ElementTree as xmlElementTree
# from robot.libraries.BuiltIn import BuiltIn
# from robot.api.deco import keyword
# from CTL.Robot.Selenium import click_element_using_javascript,scroll_element_by_javascript,input_text_using_javascript,open_browser_maximized
# from dec.PageObjects.decweb.decmicroappPage import *
# from dec.PageObjects.decweb.decwebPage import *
from tkinter.constants import CURRENT
from selenium.webdriver.chrome import service
from builtins import str, int
from _ast import Try
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from _hashlib import new
# from symbol import except_clause
from _collections_abc import zip_iterator

# from aifc import data

# data = (dict)


ROBOT_LISTENER_API_VERSION = 2

xml_required = [
    "Results/output.xml",
    "Failed_ScreenShot/error.png"
]

username = "leon.prajwals@lumen.com"
password = "LvN0gqpWpOSqv5UfgKHH1DBF"


def start_test(name, attributes):
    # create a list to capture the steps
    global step_defenition
    print("hello")
    step_defenition = []


def end_keyword(name, attributes):
    global step_defenition
    # print("abc")
    # Capture the step keywords that start with Given When Then And
    if attributes['kwname'].startswith('Given') or attributes['kwname'].startswith('When') or attributes[
        'kwname'].startswith('Then') or attributes['kwname'].startswith('And'):
        print("hi", attributes['kwname'])
        step_defenition.append(attributes['kwname'])
        print("step_endk", step_defenition)


def end_test(name, attrs):
    # This code runs after the script fails
    print("  hey   ")
    if attrs['status'] == 'FAIL':

        print('Test "%s" failed: %s' % (name, attrs['message']))
        print("step_endt", step_defenition)
        a = attrs['message']
        error_message = []
        summary_message = []
        for k in a.split("\n"):
            error_without_spcl_char = re.sub(r"[^a-zA-Z0-9]+", ' ', k)
            print("spcl:", error_without_spcl_char)
            error_message.append(error_without_spcl_char)
            print(error_message)  # captured error without special characters

        summary_message.append(name)
        print(summary_message)
        data = "\n".join(item for item in step_defenition)
        final_data = data + '\n' + 'Error:' + error_message[0]

        final_description = []
        final_description.append(final_data)
        zip_iterator = zip(summary_message, final_description)
        se_dictionary = dict(zip_iterator)
        print("dictionary:", se_dictionary)

        defect_api_call(se_dictionary)
        # attachment_to_issue()


def defect_api_call(error):
    # with open(filepath) as file:
    #     data=file.read()
    #     print("data:",data)
    # data ={
    # "application": "QR",
    # "env": "itv1",
    # "error": "HTTP Status 404"
    # }
    global data
    for key, value in error.items():
        error_summary = key
        error_description = value
        json_data = {"application": "QR", "env": "itv1", "error": error_description}
        print("data:", json_data)
        data = json.dumps(json_data)
        print("json_data", data)
        defectCount = check_defect_exist(error_summary, error_description)
        if (defectCount == 0):
            print("hi")
            response = requests.post('http://usomawvtw02:8000/defect_predict/', data)
            print("Response:", response.text)

            json_obj = json.loads(response.text)
            print("json:", json_obj)
            index = 0
            for key in json_obj[index]:

                if (key == 'Defect'):
                    Defect = json_obj[index][key]

                    print("Defect:", Defect)
            Defect = "True"
            if (Defect == "False"):
                print("Not a Defect")
            else:
                raise_defect(error_summary, error_description)

        else:
            print("Defect exists")


def raise_defect(error_summary, error_description):
    print("sys", os.environ.get("https.protocols"))
    os.environ["https.protocols"] = "TLSv1,TLSv1.1,TLSv1.2"
    print("sys1:", os.environ.get("https.protocols"))

    # username = "abinash.subudhi@lumen.com:5d51b846c6b9320d9ea59548"
    userPwd = "leon.prajwals@lumen.com:LvN0gqpWpOSqv5UfgKHH1DBF"
    user = username
    passw = password
    base64string = "Basic" + str(base64.b64encode(b'userPwd'))
    # base64.b64encode("userPwd".encode("utf-8"))    # can use this also
    header = ("Authorization: Basic %s" % base64string)
    print("head1:", header)
    ActiveSprintValue = active_sprint()
    # ActiveSprintValue = 10002
    print("Active Sprint Value2:", ActiveSprintValue)
    message = generate_Post_Jira_Defect_Payload(error_summary, error_description)
    print("message1", message)
    headers = {'Content-type': 'application/json', 'Accept': 'application/json'}
    # auth=HTTPBasicAuth('user', 'passw')
    response = requests.post("https://ctl.atlassian.net/rest/api/2/issue/", auth=(user, passw),
                             data=json.dumps(message), headers=headers)
    print("body1:", json.dumps(message))
    print("respo1:", response.text)
    data = response.json()
    defect_id = data['key']
    print("test", defect_id)
    attachment_to_issue(defect_id)
    print("defect created")


def generate_Post_Jira_Defect_Payload(summary, description):
    commanfields = {}
    ActiveSprintValue = active_sprint()
    # ActiveSprintValue = 10002
    commanfields["customfield_10021"] = ActiveSprintValue
    commanfields["summary"] = summary
    commanfields['description'] = description
    commanfields['customfield_10001'] = '3672'  # teamID #done
    commanfields['environment'] = 'Test 1'
    # json_data = json.dumps(commanfields)
    print("commanfields test", commanfields)

    projectAttr = {}
    projectAttr['id'] = 10308  # pro id
    commanfields['project'] = projectAttr
    print("projectAttr test", projectAttr)

    issuetypeAttr = {}
    issuetypeAttr['id'] = 10004  # Seme for all teams
    commanfields['issuetype'] = issuetypeAttr
    print("issuetypeAttr test:", issuetypeAttr)

    assigneeAttr = {}
    assigneeAttr['accountId'] = '6155e6c878e5e400702a36b0'  # Check with Kiran
    assigneeAttr['emailAddress'] = 'leon.prajwals@lumen.com'
    commanfields['assignee'] = assigneeAttr

    TestTypeAttr = {}
    TestTypeAttr['value'] = 'System'
    commanfields['customfield_10231'] = TestTypeAttr

    versionAttr = []
    versionName = {}
    versionName['name'] = "EDGE PI14 Sep21-Jan10"  # release
    versionAttr.append(versionName)

    commanfields['versions'] = versionAttr
    print("versionAttr test:", versionAttr)
    # json_data = json.dumps(commanfields)
    commanfields['labels'] = ["STR", "ADL"]
    JiraDefectPayload = {}
    JiraDefectPayload['fields'] = commanfields

    # json_data = json.dumps(JiraDefectPayload)
    # print("JiraDefectPayload :",json_data)
    print("JiraDefectPayload", JiraDefectPayload)

    return JiraDefectPayload


def attachment_to_issue(defect_id):
    # dfile = open("datafile.txt", "rb")
    print("am here")
    url = "https://ctl.atlassian.net/rest/api/2/issue/" + defect_id + "/attachments"
    path = os.path.join(os.getcwd(), xml_required[1])
    files = {'file': open(path, 'rb')}
    headers = {'X-Atlassian-Token': 'no-check',
               'Authorization': 'Basic YWJpbmFzaC5zdWJ1ZGhpQGx1bWVuLmNvbTpTR1gxVHZPVWxTSjNIQTdIT1VGeDdDQTk='}
    user = username
    passw = password
    test_res = requests.post(str(url), auth=(user, passw), files=files, headers=headers)
    print("test2", test_res)
    if test_res.ok:
        print(" File uploaded successfully ! ")
        print(test_res.text)
    else:
        print(" Please Upload again ! ")


def active_sprint():
    print("sys", os.environ.get("ActiveSprint"))
    user = username
    passw = password
    base64string = "Basic" + str(base64.b64encode(b'username'))
    response = requests.get("https://ctl.atlassian.net/rest/agile/1.0/board/911/sprint?state=active",
                            auth=(user, passw))  # board id
    print("respo:", response.text)

    json_obj = json.loads(response.text)
    print("json:", json_obj)
    # index=0
    ActiveSprintId = json_obj['values'][1]['id']
    print("id:", json_obj['values'][1]['id'])
    abc = 12217
    return abc


def check_defect_exist(summary, description):
    user = username
    passw = password
    ActiveSprintValue = active_sprint()
    print("heyw", ActiveSprintValue)
    base64string = "Basic" + str(base64.b64encode(b'username'))
    url = "https://ctl.atlassian.net/rest/api/2/search?jql=issuetype = bug and status != CLOSED and team = 3672 and sprint = 8545 and summary ~ '" + summary + "' and description ~ '" + description + "'"
    print("url:", url)
    response = requests.get(str(url), auth=(user, passw))
    print("respo:", response.text)
    json_obj = json.loads(response.text)
    # print("json:",json_obj)
    # index=0
    TotalDefect = json_obj['total']
    print("total", json_obj['total'])
    return TotalDefect


